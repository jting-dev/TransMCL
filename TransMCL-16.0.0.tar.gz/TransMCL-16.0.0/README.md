TransMCL
this is a transcriptome assembly tool
