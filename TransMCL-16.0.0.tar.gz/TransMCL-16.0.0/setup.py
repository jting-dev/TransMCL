from setuptools import setup
setup(
name = "TransMCL",
version = "16.0.0",
author = "SY Zhou",
packages = ['TransMCL'],
description = "transcriptome assembly tools"
)

