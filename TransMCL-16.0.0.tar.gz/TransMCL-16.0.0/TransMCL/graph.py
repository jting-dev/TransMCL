from __future__ import print_function
import os
import sys
from scipy.cluster.hierarchy import dendrogram, linkage, fcluster

def 

if __name__ == "__main__":
    pass