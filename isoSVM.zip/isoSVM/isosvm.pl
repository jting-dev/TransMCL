#! /usr/bin/perl -w
###################################################################################################
# (c) 2004 Michael Spitzer, IFG-IZKF

use diagnostics;                                            # verbose warning- and error-messages.
use strict;                                                 # This is a "must-have".
use Data::Dumper;

use lib "<put IsoSVM module installation path here>";    # add path where my custom Perl-Modules reside (~/bin/perl/)
use lib $ENV{'PWD'};

use IFG::NutsnBolts;
use IFG::Alignments;
use IsoSVM::GetFeatures;
use IsoSVM::Evaluate;
use IsoSVM::SVMLight;

sub parse_args {
# parses the arguments given via command line and builds a hash which will be returned.
# Does a little error checking and dies if something's wrong with the parameters (eg. some switch is unknown or so).
   my @args          = @{$_[0]};        # holds @ARGV
   my %param         = ();              # will be filled with the parameters from @ARGV

   for (my $i = 0; $i < scalar(@args); $i++) {
      CASE: { 
         if ($args[$i] eq '-fasta')          { $param{'fasta'}          = $args[++$i]; last CASE; }
         if ($args[$i] eq '-blast')          { $param{'blast'}          = $args[++$i]; last CASE; }
         if ($args[$i] eq '-v')              { $param{'verbose'}        = 1;           last CASE; }
         if ($args[$i] eq '-model')          { $param{'model'}          = $args[++$i]; last CASE; }
         if ($args[$i] eq '-ps')             { $param{'printseqs'}      = 1;           last CASE; }
         if ($args[$i] eq '-printallseqs')   { $param{'printallseqs'}   = 1;           last CASE; }
         if ($args[$i] eq '-debug')          { $param{'debug'}          = 1;           last CASE; }
         die "[PARAM] Bad parameters! Argument '".$args[$i]."' unknown!\n";
      }
   }
   if ($param{'fasta'} && $param{'blast'}) {
      print "[Error] Only one input option (-blast or -fasta) is allowed at a time!\n";
      exit 0;
   }
   unless ($param{'model'}) {                                                                                  # model was not specified by user
      $param{'model'} = _check4model();                                                                        # check for ".isosvm" in $HOME *and* current directory
   }
   $param{'basename'}      = IFG::NutsnBolts::cut_file_extension(($param{'fasta'} || $param{'blast'}));
   $param{'svmldata'}      = $param{'basename'}.'.svml';
   $param{'classfile'}     = $param{'basename'}.'.class';
   $param{'consolewidth'}  = 150;
   $param{'offset'}        = 3;
   $param{'maxdeflinelen'} = 50;
   return \%param;
}

sub _check4model {
# "$HOME/.isosvm" is preferred!!!
   my $model   = '';

   if ((-e $ENV{'PWD'}.'/.isosvm') && (-d $ENV{'PWD'}.'/.isosvm')) {                                           # PWD/.isosvm exists and is a directory
      if (-s $ENV{'PWD'}.'/.isosvm/isosvm.model') {
         $model = $ENV{'PWD'}.'/.isosvm/isosvm.model';
      }
   }
   if ((-e $ENV{'HOME'}.'/.isosvm') && (-d $ENV{'HOME'}.'/.isosvm')) {                                         # $HOME/.isosvm exists and is a directory
      if (-s $ENV{'HOME'}.'/.isosvm/isosvm.model') {
         $model = $ENV{'HOME'}.'/.isosvm/isosvm.model';
      }
   }
   return $model;
}

### main ##########################################################################################

$| = 1;      # flushes buffer for prints etc. immediately!

if ((!(@ARGV)) || ($ARGV[0] eq '-h') || ($ARGV[0] eq '-?') || ($ARGV[0] eq '?') || ($ARGV[0] eq '-help')) {
print <<EOF;
\nSYNOPSIS:
isosvm.pl [-h/-v]

-h             : display this short description
-v             : be really, really noisy

-fasta <file>  : alignment in FASTA format
-blast <file>  : BLAST report
-model <file>  : the IsoSVM kernel model (default: ".isosvm/isosvm.model" in your home directory)

-ps            : "printseqs" -> print a visualization of all seqpairs found to be isoforms
                 ("-printallseqs" prints all seqpairs, first all isoforms, then all non-isoforms)

EOF
exit 0;
}

my $param = &parse_args(\@ARGV);

if ($param->{'verbose'}) { print "\nUsing SVM model '".$param->{'model'}."'\n"; }

if ($param->{'blast'}) {
   if ($param->{'verbose'}) { print "\nConverting BLAST report '".$param->{'blast'}."'..."; }
   IFG::Alignments::run_mview($param->{'blast'}, $param->{'basename'}.'.fasta', $param);                                                              # convert BLAST to FASTA using MVIEW
   $param->{'fasta'} = $param->{'basename'}.'.fasta';                                                                                                 # remember the name of the FASTA file
   if ($param->{'verbose'}) { print "done\n"; }
}
if ($param->{'verbose'}) { print "\nReading alignment '".$param->{'fasta'}."'..."; }
my ($in, $codes) = IFG::Alignments::read_aln($param->{'fasta'});                                                                                      # read alignment (or FASTA-converted BLAST report :-)
$param->{'seqlen'} = length($in->{$codes->[0]});                                                                                                      # get length of the alignment
if ($param->{'verbose'}) { print "done (".scalar(@{$codes})." sequences)\n"; }

if ($param->{'verbose'}) { print "\nCalculating features:\n"; }
my $features = IsoSVM::GetFeatures::get_features($in, $codes, 0, $param);                                                                          # get features for all sequence-pairs
if ($param->{'verbose'}) { print "done in ".$param->{'iso_time'}."s (".IFG::NutsnBolts::round(($param->{'iso_numtrials'} / ($param->{'iso_time'} || 1)), 2)." sequence-pairs/s)\n"; }

if ($param->{'verbose'}) { print "\nWriting SVMLight data to '".$param->{'svmldata'}."'..."; }
IsoSVM::SVMLight::write_svmlight_file($features, $param->{'svmldata'}, $param);                                                                    # get features for all sequence-pairs
if ($param->{'verbose'}) { print "done\n"; }

if ($param->{'verbose'}) { print "\nClassifying data '".$param->{'svmldata'}."'..."; }
my $log = IsoSVM::SVMLight::run_svm_classify($param->{'svmldata'}, $param->{'model'}, $param->{'classfile'}, $param);                              # classify!
if ($param->{'verbose'}) { print "done\n"; }

if ($param->{'verbose'}) { print "\nReading classification results '".$param->{'classfile'}."'..."; }
my $class = IsoSVM::SVMLight::read_svmlight_classification_results($param->{'classfile'}, $param);                                                 # read classification results
if ($param->{'verbose'}) { print "done\n"; }

if ($param->{'verbose'}) { print "\nParsing classification results:\n"; }
my $stats = 0;
($features, $stats) = IsoSVM::Evaluate::parse_classification_results($features, $class, $param);                                                   # parse classification results
my ($isoforms, $isostats, $parastats, $unknown_stats) = IsoSVM::Evaluate::get_isoforms($features, $in, $codes, $param);
if ($param->{'verbose'}) { print "done\n"; }

if ($param->{'verbose'}) { print "\n>>> Printing results/isoforms:\n"; }
IsoSVM::Evaluate::print_stats($stats, $isoforms, $param);
IsoSVM::Evaluate::print_isoforms($isoforms, $isostats, $in, $codes, $param);
if ($param->{'printallseqs'}) {
   if ($param->{'verbose'}) { print "\n>>> Printing non-splice-variants:\n"; }
   IsoSVM::Evaluate::print_paralogs($isoforms, $isostats, $parastats, $unknown_stats, $features, $in, $codes, $param);
   if ($param->{'verbose'}) { print "\n>>> Printing unknown / ignored sequences:\n"; }
   IsoSVM::Evaluate::print_unknown_ignored($isoforms, $isostats, $parastats, $unknown_stats, $features, $in, $codes, $param);
}
if ($param->{'verbose'}) { print "done\n"; }

if ($param->{'verbose'}) { print "\n"; }
exit 0;
