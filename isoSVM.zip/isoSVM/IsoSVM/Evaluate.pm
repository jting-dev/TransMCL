package IsoSVM::Evaluate;
require Exporter;

use strict;
use diagnostics;

use Data::Dumper;

our @EXPORT  = qw(parse_classification_results        print_stats          get_isoforms);

our $VERSION = "07.05.2004";

sub sort_num { $a <=> $b }

sub parse_classification_results {
   my $features      = $_[0];
   my $class         = $_[1];
   my $param         = $_[2];
   my %stats         = ();
   my $counter       = 0;

   foreach my $sample (sort(sort_num keys(%{$features}))) {
      if (($features->{$sample}->{'feature1'} != -1) && ($features->{$sample}->{'feature2'} != -1) && ($features->{$sample}->{'feature3'} != -1)) {   # SVM data was written for samples with feature1.2.3 != -1 ONLY!!!
         $features->{$sample}->{'score'} = $class->[$counter];
         if ($class->[$counter] > 0) {
            $features->{$sample}->{'class'} = 1;
            ($stats{'pos'}) ? ($stats{'pos'}++) : ($stats{'pos'} = 1);
         }
         elsif ($class->[$counter] < 0) {
            $features->{$sample}->{'class'} = -1;
            ($stats{'neg'}) ? ($stats{'neg'}++) : ($stats{'neg'} = 1);
         }
         else {
            $features->{$sample}->{'class'} = '-';
            ($stats{'unknown'}) ? ($stats{'unknown'}++) : ($stats{'unknown'} = 1);
         }
         $counter++;                                                                                                                                  # increase pointer to the next classification result
      }
      else {                                                                                                                                          # if one of the features is "-1" (indicated 100% or 0% sequence similarity), ignore this sequence
         $features->{$sample}->{'class'} = '-';
         ($stats{'ignored'}) ? ($stats{'ignored'}++) : ($stats{'ignored'} = 1);
      }
   }
   return ($features, \%stats);
}

sub get_isoforms {
   my $features                                          = $_[0];
   my $in                                                = $_[1];
   my $codes                                             = $_[2];
   my $param                                             = $_[3];
   my (%isoforms, %isostats, %parastats, %unknownstats)  = ((), (), (), ());

   foreach my $sample (sort(sort_num keys(%{$features}))) {
      if (($features->{$sample}->{'class'} ne '-') && ($features->{$sample}->{'class'} == 1)) {
         push(@{$isoforms{$features->{$sample}->{'seq1'}}}, $features->{$sample}->{'seq2'});
         $isostats{$features->{$sample}->{'seq1'}}->{$features->{$sample}->{'seq2'}}->{'feature1'} = $features->{$sample}->{'feature1'};
         $isostats{$features->{$sample}->{'seq1'}}->{$features->{$sample}->{'seq2'}}->{'feature2'} = $features->{$sample}->{'feature2'};
         $isostats{$features->{$sample}->{'seq1'}}->{$features->{$sample}->{'seq2'}}->{'feature3'} = $features->{$sample}->{'feature3'};
         $isostats{$features->{$sample}->{'seq1'}}->{$features->{$sample}->{'seq2'}}->{'score'}    = $features->{$sample}->{'score'};
         $isostats{$features->{$sample}->{'seq1'}}->{$features->{$sample}->{'seq2'}}->{'sample'}   = $sample;
      }
      elsif (($features->{$sample}->{'class'} ne '-') && ($features->{$sample}->{'class'} == -1)) {
         $parastats{$features->{$sample}->{'seq1'}}->{$features->{$sample}->{'seq2'}}->{'feature1'} = $features->{$sample}->{'feature1'};
         $parastats{$features->{$sample}->{'seq1'}}->{$features->{$sample}->{'seq2'}}->{'feature2'} = $features->{$sample}->{'feature2'};
         $parastats{$features->{$sample}->{'seq1'}}->{$features->{$sample}->{'seq2'}}->{'feature3'} = $features->{$sample}->{'feature3'};
         $parastats{$features->{$sample}->{'seq1'}}->{$features->{$sample}->{'seq2'}}->{'score'}    = $features->{$sample}->{'score'};
         $parastats{$features->{$sample}->{'seq1'}}->{$features->{$sample}->{'seq2'}}->{'sample'}   = $sample;
      }
      else {
         $unknownstats{$features->{$sample}->{'seq1'}}->{$features->{$sample}->{'seq2'}}->{'feature1'} = $features->{$sample}->{'feature1'};
         $unknownstats{$features->{$sample}->{'seq1'}}->{$features->{$sample}->{'seq2'}}->{'feature2'} = $features->{$sample}->{'feature2'};
         $unknownstats{$features->{$sample}->{'seq1'}}->{$features->{$sample}->{'seq2'}}->{'feature3'} = $features->{$sample}->{'feature3'};
         $unknownstats{$features->{$sample}->{'seq1'}}->{$features->{$sample}->{'seq2'}}->{'score'}    = -1;
         $unknownstats{$features->{$sample}->{'seq1'}}->{$features->{$sample}->{'seq2'}}->{'sample'}   = $sample;
      }
   }
   return (\%isoforms, \%isostats, \%parastats, \%unknownstats);
}

sub print_stats {
   my $stats         = $_[0];
   my $isoforms      = $_[1];
   my $param         = $_[2];

   my $ignored_seqs = ((($param->{'numtrials'} || 0) - (($stats->{'pos'} || 0) + ($stats->{'neg'} ||0) + ($stats->{'unknown'} || 0))) || 0);
   if ($stats->{'ignored'} && ($ignored_seqs != $stats->{'ignored'})) { print "[IsoSVM::Evaluate::print_stats()] Ignored-Seqs Mismatch Error\n"; }
   print 'Number of analysed sequence pairs   : '.($param->{'numtrials'} || 0)."\n";
   print 'Number of splice variant pairs      : '.($stats->{'pos'} || 0)."\n";
   print 'Number of none splice variants pairs: '.($stats->{'neg'} || 0)."\n";
   print 'Number of ignored sequence pairs    : '.($stats->{'ignored'} || 0)."\n";
   print 'Number of unknown samples           : '.($stats->{'unknown'} || 0)."\n";
   print 'Number of sequences being isoforms  : '.scalar(keys(%{$isoforms}))."\n\n";
}

sub _remove_all_gap_columns {
   my $seq1          = $_[0];       # reference to seq1
   my $seq2          = $_[1];       # reference to seq2
   my $param         = $_[2];
   my ($tmp1, $tmp2) = ('', '');

   for (my $i = 0; $i < length($$seq1); $i++) {
      if ((substr($$seq1, $i, 1) ne '-') || (substr($$seq2, $i, 1) ne '-')) {
         $tmp1 .= substr($$seq1, $i, 1);
         $tmp2 .= substr($$seq2, $i, 1);
      }
   }
   return (\$tmp1, \$tmp2);         # return reference only!!!
}

sub print_isoforms {
   my $isoforms      = $_[0];
   my $isostats      = $_[1];
   my $in            = $_[2];
   my $codes         = $_[3];
   my $param         = $_[4];

   foreach my $seq1 (sort(sort_num keys(%{$isoforms}))) {
      print "Sequence #".($seq1 + 1)." ('".$codes->[$seq1]."') is a splice-variant to:\n";
      foreach my $seq2 (@{$isoforms->{$seq1}}) {
         print "   #".($seq2 + 1)." ('".$codes->[$seq2]."')\t->   ".
               "inverseCBINcount ".IFG::NutsnBolts::round($isostats->{$seq1}->{$seq2}->{'feature2'}, 5)." / ".
               "MatchMismatchRate ".IFG::NutsnBolts::round($isostats->{$seq1}->{$seq2}->{'feature3'}, 5)." / ".
               "Similarity ".IFG::NutsnBolts::round($isostats->{$seq1}->{$seq2}->{'feature1'}, 5)."   -> ".
               "[Score: ".$isostats->{$seq1}->{$seq2}->{'score'}."]\n";
         if ($param->{'printseqs'} || $param->{'printallseqs'}) {
            my ($tmpseq1, $tmpseq2) = _remove_all_gap_columns(\$in->{$codes->[$seq1]}, \$in->{$codes->[$seq2]}, $param);                                             # only used for pretty printing! ($seq1, $seq2 are references!!!)
            IFG::Alignments::pretty_print_seqpair($tmpseq1, $tmpseq2, \$codes->[$seq1], \$codes->[$seq2], $param->{'consolewidth'},
                                                  $param->{'offset'}, $param->{'maxdeflinelen'}, $param);
         }
      }
      print "\n";
   }
}

sub print_paralogs {
   my $isoforms      = $_[0];
   my $isostats      = $_[1];
   my $parastats     = $_[2];
   my $unknownstats  = $_[3];
   my $features      = $_[4];
   my $in            = $_[5];
   my $codes         = $_[6];
   my $param         = $_[7];

   for (my $i = 0; $i < (scalar(@{$codes}) - 1); $i++) {
      for (my $j = ($i + 1); $j < scalar(@{$codes}); $j++) {
         my $found = 0;
         foreach my $isoform (@{$isoforms->{$i}}) {
            $found = ($j == $isoform);
            last if $found;
         }
         unless ($found) {
            if ($parastats->{$i}->{$j}) {
               print "Sequence #".($i + 1)." ('".$codes->[$i]."') is a paralog to:\n";
               print "   #".($j + 1)." ('".$codes->[$j]."')\t->   ".
                     "Mean-CBIN-Len ".IFG::NutsnBolts::round($parastats->{$i}->{$j}->{'feature2'}, 5)." / ".
                     "Match-Rate ".IFG::NutsnBolts::round($parastats->{$i}->{$j}->{'feature3'}, 5)." / ".
                     "SeqID ".IFG::NutsnBolts::round($parastats->{$i}->{$j}->{'feature1'}, 5)."   -> ".
                     "[Score: ".$parastats->{$i}->{$j}->{'score'}."]\n";
               my ($tmpseq1, $tmpseq2) = _remove_all_gap_columns(\$in->{$codes->[$i]}, \$in->{$codes->[$j]}, $param);                                             # only used for pretty printing! ($i, $j are references!!!)
               IFG::Alignments::pretty_print_seqpair($tmpseq1, $tmpseq2, \$codes->[$i], \$codes->[$j], $param->{'consolewidth'},
                                                     $param->{'offset'}, $param->{'maxdeflinelen'}, $param);
               print "\n";
            }
         }
      }
   }
}

sub print_unknown_ignored {
   my $isoforms      = $_[0];
   my $isostats      = $_[1];
   my $parastats     = $_[2];
   my $unknownstats  = $_[3];
   my $features      = $_[4];
   my $in            = $_[5];
   my $codes         = $_[6];
   my $param         = $_[7];

   for (my $i = 0; $i < (scalar(@{$codes}) - 1); $i++) {
      for (my $j = ($i + 1); $j < scalar(@{$codes}); $j++) {
         my $found = 0;
         foreach my $isoform (@{$isoforms->{$i}}) {
            $found = ($j == $isoform);
            last if $found;
         }
         unless ($found) {
            if ($unknownstats->{$i}->{$j}) {
               print "Sequence #".($i + 1)." ('".$codes->[$i]."') unknown/ignored to:\n";
               print "   #".($j + 1)." ('".$codes->[$j]."')\t->   ".
                     "Mean-CBIN-Len ".$unknownstats->{$i}->{$j}->{'feature2'}." / ".
                     "Match-Rate ".$unknownstats->{$i}->{$j}->{'feature3'}." / ".
                     "SeqID ".$unknownstats->{$i}->{$j}->{'feature1'}."   -> ".
                     "[Score: ".$unknownstats->{$i}->{$j}->{'score'}."]\n";
               my ($tmpseq1, $tmpseq2) = _remove_all_gap_columns(\$in->{$codes->[$i]}, \$in->{$codes->[$j]}, $param);                                             # only used for pretty printing! ($i, $j are references!!!)
               IFG::Alignments::pretty_print_seqpair($tmpseq1, $tmpseq2, \$codes->[$i], \$codes->[$j], $param->{'consolewidth'},
                                                     $param->{'offset'}, $param->{'maxdeflinelen'}, $param);
               print "\n";
            }
         }
      }
   }
}
