package IsoSVM::SVMLight;
require Exporter;

use strict;
use diagnostics;

use Data::Dumper;

our @EXPORT  = qw(write_svmlight_file              run_svm_classify);

our $VERSION = "07.05.2004";

sub sort_num { $a <=> $b }

sub write_svmlight_file {
   my $features         = $_[0];
   my $filename         = $_[1];
   my $param            = $_[2];

   open(_train_, '>'.$filename) or die "[IOErr] Could not open '$filename' for write access!\n";
   foreach my $sample (sort(sort_num keys(%{$features}))) {                                                                                           # step thru all collected samples; those were collected in "all_against_all()"
      my $counter = 1;
      if (($features->{$sample}->{'feature1'} != -1) && ($features->{$sample}->{'feature2'} != -1) && ($features->{$sample}->{'feature3'} != -1)) {   # only samples with feature1 being > 0 are to be included for SVM classification!
         print _train_ ($features->{$sample}->{'class'} eq '-' ? '0' : $features->{$sample}->{'class'});                                              # print the classification first followed by a space character
         while ($features->{$sample}->{'feature'.$counter}) {                                                                                         # does feature-# "$counter" exist?
            print _train_ ' '.$counter.':'.($features->{$sample}->{'feature'.$counter} eq '-' ? '0' : $features->{$sample}->{'feature'.$counter});    # if it does, write "<SPACE>featurenumber:feature" to the file
            $counter++;                                                                                                                               # increase the feature counter (this one allowes indefinite nnumber of features)
         }
         print _train_ "\n";                                                                                                                          # we worked thru all features and terminate the line by a CR
      }
   }
   close(_train_);
}

sub run_svm_classify {
   my $svmlfile         = $_[0];
   my $model            = $_[1];
   my $classfile        = $_[2];
   my $param            = $_[3];

   my $shellstring = '';
   if ($param->{'svmlightdir'}) { $shellstring = $param->{'svmlightdir'}."/svm_classify -v 2 $svmlfile $model $classfile"; }
   else { $shellstring = "svm_classify -v 2 $svmlfile $model $classfile"; }                                                                           # ...and start the classification process
   my $log = `$shellstring`;
   return $log;
}

sub read_svmlight_classification_results {
   my $filename         = $_[0];
   my $param            = $_[1];
   my @class            = ();

   open(_class_, "<$filename") or die "[IOErr] Could not open '$filename', exiting...\n";
   until (eof(_class_)) {
      my $line = <_class_>;
      chomp($line);
      push(@class, $line);
   }
   close(_class_);
   return \@class;
}
