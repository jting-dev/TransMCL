package IsoSVM::GetFeatures;
require Exporter;

use strict;
use diagnostics;

use Data::Dumper;

#use constant mean_csi_length_threshold    => 14;                     # heuristics!!! (CSI = consecutive sequence idenities) for isoform determination
#use constant min_seq_identity             => 0.1;                    # dito!!! for isoform determination

our @EXPORT  = qw(check_for_isoform       get_features);

our $VERSION = "27.01.2003";

######################## old stuff! Needed for comparison in PhD!
#
#sub _potential_equation {
#   my $x    = $_[0];
#
#   return (72.6 / ($x + 0.26)) + (($x / 57.7) ^ 4.4);
#}
#
#sub _potential_equation_customized {
#   my $x    = $_[0];
#
#   return ((500 / ($x + 0.01)) + (($x / 25) ^ 2.5));
#}
#
#sub _decide_isoform {
#   my $csi_rate                  = $_[0];
#   my $mean_csi_len              = $_[1];
#   my $seq_id                    = $_[2];
#   my $param                     = $_[3];
#   my ($pot, $cpot)              = (0, 0);      # potential / custom potential
#
#   $pot  = _potential_equation(($seq_id * 100));                                                                                    # $seq_id ranges from 0..1, but we need 0..100 for the potential function
#   $cpot = _potential_equation_customized(($seq_id * 100));                                                                         # $seq_id ranges from 0..1, but we need 0..100 for the potential function
#   if ($param->{'debug'}) { print "   (pot: ".IFG::NutsnBolts::round($pot, 2)." -> cpot: ".IFG::NutsnBolts::round($cpot, 2).")   "; }
#   return ($mean_csi_len >= $cpot);
#}
#
#sub check_for_isoform_old {
#   my $seq1             = $_[0];                   # sequence #1 (a reference!)
#   my $seq2             = $_[1];                   # sequence #2 (a reference!)
#   my $param            = $_[2];
#
#   my ($identities, $pro, $contra)              = _get_sequence_identities_for_isoform($seq1, $seq2, $param);                       # get identities (array)
#   my ($csi_rate, $mean_csi_len, $seq_identity) = _evaluate_values_isoform($identities, $pro, $contra);                             # calc CSI-stuff!
#   my $isoform                                  = _decide_isoform($csi_rate, $mean_csi_len, $seq_identity, $param);
#   return ($isoform, $mean_csi_len, $seq_identity);
#}
#
########################

sub _get_sequence_identities_for_isoform {
# calculates the sequence identities (and non-identities!) for two sequences
   my $seq1             = $_[0];       # sequence #1 (reference!)
   my $seq2             = $_[1];       # sequence #2 (reference!)
   my $param            = $_[2];
   my @identities       = ();
   my $pro              = 0;

   for (my $i = 0; $i < length($$seq1); $i++) {
      if ((substr($$seq1, $i, 1) ne '-') || (substr($$seq2, $i, 1) ne '-')) {                                                       # do NOT consider positions for evaluation where *BOTH* sequences have gaps (thus skipping regions where both seqs have gaps!!!)!
         if (substr($$seq1, $i, 1) eq substr($$seq2, $i, 1)) {
            push(@identities, 1);                                                                                                   # '1'  => identical
            $pro++;                                                                                                                 # count positions with identical characters
         }
         else {
            push(@identities, -1);                                                                                                  # '-1' => not identical
         }
      }
   }
   return (\@identities, ($pro / scalar(@identities)));                                                                             # @identities holds only results from positions with one or more non-gap characters!!! All-Gap-columns are ignored!!!!
}

sub _evaluate_values_isoform {
   my $identities                                     = $_[0];
   my $param                                          = $_[1];
   my $len                                            = scalar(@{$identities});       # length of the array/alignment (NON-all-gap columns only!!!)
   my ($id_num, $cbin_len, $mean_cbin_len, $cbin_num) = (0, 1, 0, 0);

   for (my $i = 1; $i < $len; $i++) {
         if (($identities->[$i] == $identities->[$i-1]) && ($i < ($len-1))) {                                                       # if the actual and the previous position have the same state (0 / 1 = not equal / equal)...
            $id_num++;                                                                                                              # ...increase the counter for *overall* consecutive sequence identities... (=> sum up all identities *AND* non-identities!)
            $cbin_len++;                                                                                                            # ...and increase the counter for the length of the actual *local* CSI
         }                                                                                                                          # >>> if $i reached the end of the array "!($i < ($len-1))": close the actual CSI and evaluate!!!! Else we would be missing the last CSI!!!
         else {                                                                                                                     # if the actual and the previous position have different states...
            $mean_cbin_len += $cbin_len;                                                                                            # ...add the length of the actual CSI to the mean_csi_length-variable...
            $cbin_num++;                                                                                                            # ...increase the counter for the number of CSIs...
            $cbin_len = 1;                                                                                                          # ...and set the length of the actual CSI to zero (= start a new CSI)
         }
   }
   if ($param->{'debug'}) {
      $param->{'sum_csi_len'}    = $mean_cbin_len;
   }
   $mean_cbin_len         = (1 / $cbin_num);                                                                                        # calculate the mean length of a CSI (length / num) and *normalize* by dividing by length
   my $matchmismatchrate  = ($id_num / $len);                                                                                       # calculate the rate of consecutive identities per "sequence" (sequence always means 'non-all-gap columns' here!!!) (= match/mismatch rate)
   if ($param->{'debug'}) {
      $param->{'mean_csi_len'}   = $mean_cbin_len;
      $param->{'csi_num'}        = $cbin_num;
      $param->{'aln_len'}        = $len;
   }
   return ($mean_cbin_len, $matchmismatchrate);
}

sub check_for_isoform {
   my $seq1             = $_[0];                   # sequence #1 (it's a reference!)
   my $seq2             = $_[1];                   # sequence #2 (it's a reference!)
   my $param            = $_[2];

   my ($identities, $seq_similarity) = _get_sequence_identities_for_isoform($seq1, $seq2, $param);                                     # get identities (array)
   if ($param->{'debug'}) {
      $param->{'id_array'} = join('', @{$identities});
      $param->{'id_array'} =~ s/\-1/0/g;
   }
   if (($seq_similarity > 0) && ($seq_similarity < 1)) {                                                                             # sequences with zero or 100% similarity can't be isoforms!!!
      my ($mean_cbin_len, $matchmismatchrate) = _evaluate_values_isoform($identities, $param);                                         # calc CSI-based-stuff!
      return ($seq_similarity, $mean_cbin_len, $matchmismatchrate);
   }
   else { return ($seq_similarity, -1, -1, -1); }
}

sub get_features {
   my $in                              = $_[0];
   my $codes                           = $_[1];
   my $blast_par                       = $_[2];                               # this is only (!!!) handed to the sub from RiPE to make sure only sequences from the same taxon are compared! If undef, all sequences are compared!
   my $param                           = $_[3];
   my $numseqs                         = scalar(@{$codes});
   my $numtrials                       = (($numseqs - 1) * $numseqs) / 2;     # number of comparisons the algorithm has to perform (for percentage display)
   my ($sample, $b4percent, $counter)  = (0, 0, 0);
   my (%features, %features2)          = ((), ());

   if ($param->{'verbose'}) { print '   getting features for '.$numtrials.' samples/seq-pairs: 0%'; }
   my $pretime = time();
   for (my $i = 0; $i < ($numseqs - 1); $i++) {
      for (my $j = ($i + 1); $j < $numseqs; $j++) {
         $counter++;
         my $percent    = IFG::NutsnBolts::round((($counter / $numtrials) * 100), 0);
         if ($percent > $b4percent) {
            if (($percent % 10) == 0) { if ($param->{'verbose'}) { print "$percent%"; } }
            else { if ($param->{'verbose'}) { print '.'; } }
            $b4percent = $percent;
         }
         if ((!($blast_par)) || ($blast_par->{$codes->[$i]}->{'taxon'} eq $blast_par->{$codes->[$j]}->{'taxon'})) {
            my ($seq_similarity, $mean_cbin_len, $matchmismatchrate) = check_for_isoform(\$in->{$codes->[$i]}, \$in->{$codes->[$j]}, $param);
            if ($param->{'debug'}) {
               print ">>> $matchmismatchrate / $mean_cbin_len / $seq_similarity\n";
               #$param->{'debug_samples'}->{$i}->{$j}->{'mean_csi_len'} = $param->{'mean_csi_len'};
               #$param->{'debug_samples'}->{$i}->{$j}->{'csi_num'}      = $param->{'csi_num'};
               #$param->{'debug_samples'}->{$i}->{$j}->{'aln_len'}      = $param->{'aln_len'};
            }
            $features{$sample}->{'seq1'}     = ($i);                                                                                               # store array index in defline array of first sequence
            $features{$sample}->{'seq2'}     = ($j);                                                                                               # store array index in defline array of second sequence
            $features{$sample}->{'class'}    = '-';                                                                                                # store classification of sample "$counter" ('-' is necessary, a ZERO won't work!!!)
            $features{$sample}->{'feature1'} = $seq_similarity;                                                                                    # store feature #3 ('-' is needed, a ZERO won't work!!!)
            $features{$sample}->{'feature2'} = $mean_cbin_len;                                                                                     # store feature #1 ('-' is needed, a ZERO won't work!!!)
            $features{$sample}->{'feature3'} = $matchmismatchrate;                                                                                 # store feature #2 ('-' is needed, a ZERO won't work!!!)
            if ($seq_similarity == -1) { print ">>> FEATURE1: ".$features{$sample}->{'feature1'}."\n"; }
            $sample++;
         }
      }
   }
   if ($param->{'verbose'}) { print "\n"; }
   $param->{'iso_numtrials'} = $numtrials;                                                                                                            # store number of trials in global parameter hash
   $param->{'numtrials'}     = $numtrials;                                                                                                            # store number of trials in global parameter hash
   $param->{'iso_time'}      = time() - $pretime;                                                                                                     # store the number of seconds needed for feature computation
   if ($param->{'iso_time'} == 0) { $param->{'time'} = 1; }
   return (\%features);
}
