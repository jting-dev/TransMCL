#! /usr/bin/perl -w

use diagnostics;                                            # verbose warning- and error-messages.
use strict;                                                 # This is a "must-have".
use Data::Dumper;

use lib "<put IsoSVM module installation path here>";    # add path where my custom Perl-Modules reside (~/bin/perl/)
use lib $ENV{'PWD'};

use IFG::NutsnBolts;

sub parse_args {
# parses the arguments given via command line and builds a hash which will be returned.
# Does a little error checking and dies if something's wrong with the parameters (eg. some switch is unknown or so).
   my @args          = @{$_[0]};        # holds @ARGV
   my %param         = ();              # will be filled with the parameters from @ARGV

   for (my $i = 0; $i < scalar(@args); $i++) {
      CASE: { 
         if ($args[$i] eq '-dir')      { $param{'dir'}     = $args[++$i]; last CASE; }
         if ($args[$i] eq '-v')        { $param{'verbose'} = 1;           last CASE; }
         die "[PARAM] Bad parameters! Argument '".$args[$i]."' unknown!\n";
      }
   }
   return \%param;
}

### main ##########################################################################################

$| = 1;      # flushes buffer for prints etc. immediately!

if ((!(@ARGV)) || ($ARGV[0] eq '-h') || ($ARGV[0] eq '-?') || ($ARGV[0] eq '?') || ($ARGV[0] eq '-help')) {
print <<EOF;
\nSYNOPSIS:
isosvm_wrapper.pl [-h/-v]

-h          : display this short description
-v          : be really, really noisy

-dir        : directory to run IsoSVM in

This is a wrapper script for IsoSVM. It submits all files with the extensions *.faa, *.fasta, *.fa
to the IsoSVM Perl script. Please note that "isosvm.pl" has to be in \$PATH for this wrapper
script to work. 

All output of IsoSVM is caught and written to a file named after the currently analyzed FASTA file,
but using the extension *.log.

(c) 2004 Michael Spitzer (Integrated Functional Genomics, Muenster, FR Germany)

EOF
exit 0;
}

my $param = &parse_args(\@ARGV);

my $dir = IFG::NutsnBolts::get_directory_content($param->{'dir'});

foreach my $file (@{$dir}) {
   if (($file =~ m/\.fasta/) || ($file =~ m/\.faa/) || ($file =~ m/\.fa/)) {
      my $basename = IFG::NutsnBolts::cut_file_extension($file);
      if ($param->{'verbose'}) { print "Classifying file: $file..."; }
      my $shellstring = 'isosvm.pl -v -fasta '.$param->{'dir'}.'/'.$file.' -printallseqs';
      my $log = `$shellstring`;
      open(_file_, '>'.$param->{'dir'}.'/'.$basename.'.log');
      print _file_ $log;
      close(_file_);
      if ($param->{'verbose'}) { print "done\n"; }
   }
}

exit 0;
